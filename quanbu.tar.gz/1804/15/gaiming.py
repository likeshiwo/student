import os
name=input('输入你要修改源文件的名字:')
name1=input('输入你要修改的新名字:')
os.rename(name,name1)
print('修改成功!')

def like():
    print('李客，1999年，9月10日')
    print('一个超级英雄的诞生!')
name=input('你叫什么?:')
if name=='李客':
    like()
else:
    print('不认识')

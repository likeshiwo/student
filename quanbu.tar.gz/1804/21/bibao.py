def wai(n):
    def nei(b):
        print('里面的数是:%d'% b)
        return b+n
    return nei
q=wai(1)(2)
print(q)

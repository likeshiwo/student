def ok():
    print('成功!!')

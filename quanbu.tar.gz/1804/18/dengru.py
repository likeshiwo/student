class MyError(Exception):
    def __init__(self,name):
        self.name=name
def dengru():
    name=input('请输入登入的账号:')
    if name!='李客':
        raise MyError('账户输入错误:')
    else:
        print('账户验证成功!')
def mima():
    pwd=input('输入登入的密码:')
    if pwd!='789':
        raise MyError('密码输入错误:')
    else:
        print('密码验证成功!')
        print('登入成功!!!')
try:
    dengru()
    mima()
except Exception as r:
    print('登入失败,失败原因:%s'% r)


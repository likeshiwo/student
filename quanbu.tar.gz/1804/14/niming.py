a=lambda x,y : x+y
print(a(1,2))
l=[(lambda x1,y1:x1+y1),(lambda x2,y2:x2-y2),(lambda x3:x3**5)]
print(l[0](2,3))
print(l[1](5,3))
print(l[2](10))

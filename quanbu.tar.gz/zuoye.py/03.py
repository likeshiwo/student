class Fa_Like:
    def __init__(self):
        print('你好')
    def __str__(self):
        return '你也是....'
    def __new__(cls):
        print('是啊')
    def __del__(self):
        print('恩')
class Son(Fa_Like):
    pass
like=Son()
print(like)

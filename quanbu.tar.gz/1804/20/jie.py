for a in range(a,b):
    return a*b
def shuzi(x,y):
    x=x+1
    y=y+1
s = shuzi(1,2)
print(s)

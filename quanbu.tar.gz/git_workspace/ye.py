import 佛祖镇楼
佛祖镇楼.fozu()

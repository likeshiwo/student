price_str=10
weight_str=input('请输入想买西瓜的重量:')
price=float(price_str)
weight=float(weight_str)
money=weight * price
print('你需要支付:',money)

class Dog_Like(object):
    __like=None
    def __init__(self):
        pass
    def __new__(cls,*k):
        if cls.__like==None:
            cls.__new=object.__new__(cls)
        return cls.__new

like=Dog_Like()
lizhe=Dog_Like()
print(id(like))
print(id(lizhe))

class Su:
    def __init__(self,b):
        self.b=b
    def js(self):
        for i in range(2,a):
            if a%i==0:
                k=k+1
    def jg(self):
        if k==0:
            print(a)
            self.b=b+1
be=Su(0)
for a in range(101,201):
    k=0
    be.js
    be.jg

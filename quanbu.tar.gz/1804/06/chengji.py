chengji=float(input('请输入成绩:'))
if chengji>60:
    print('恭喜你合格了')
    if chengji>85:
        print('可以啊小伙！')
    else:
        print('凑合吧')
else:
    print('滚蛋，学得什么')

from metest.t02 import *
 zou()
 import metest.t01
 metest.t01.zou()
 ~

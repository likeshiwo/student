class Amil:
    def __init__(self,name):
        self.name=name
    def run(self):
        print('奔跑')
class Dog(Amil):
    def __init__(self,name):
        Amil.__init__(self,name)
    def name(self):
        print('我叫:%s' % self.name)
hei=Dog('小黑')
hei.run()
hei.name()

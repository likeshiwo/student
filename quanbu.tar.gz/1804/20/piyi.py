def digui(n):
    if n==1:
        return 1
    return n*digui(n-1)
s = digui(5)
print(s)

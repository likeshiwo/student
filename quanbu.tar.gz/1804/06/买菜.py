import random
print('Welcome！')
mai=input('我们这里有水果，蔬菜，海鲜，请问你需要什么？:')
if mai == '水果':
    print('你好，欢迎来到水果店！')
    print('西瓜3.5元/斤，苹果2元/斤，橘子6元/斤')
    shuiguo=input('你需要点什么？:')
        if shuiguo=='西瓜':
            weight=float(input('输入你想要的重量:'))
            print('你还需要点什么？')
            jixu=input('苹果？橘子？还是算了？:')
                if jixu=='苹果':
                    weight4=float(input('输入你想要的重量:'))
                    print('你还需要些什么?')
                    jixu=('橘子？还是算了？')
                elif jixu=='橘子':
                    weight6=float(input('输入你想要的重量:'))
                    print('你还需要些什么？')
                    jixu=('苹果？还是算了？')
                else:
                    money=weight*3.5
                    print('你本次需要支付:',money)
                    print('好的，如果你愿意的话可以去别的地方转转')
                        if jixu=='橘子':
                            weight5=float(input('输入你想要的重量:'))
                            money=3.5*weight+2*weight4+6*weight5
                            print('你本次一共需要支付:',money)
                            print('谢谢你的光临!')
                        elif jixu=='苹果':
                            weight7=float(input('输入你想要的重量:'))
                            money=3.5*weight+2*weight4+6*weight5
                            print('你本次一共需要支付:'money)
                            print('谢谢你的光临')
                        else:
                            print('好的，如果你愿意的话可以去别的地方转转')
        elif shuiguo=='苹果':
            weight2=float(input('输入你想要的重量:'))
            print('你还需要点什么?')
            jixu=input('西瓜？橘子？还是算了？:')
            if jixu=='西瓜':
                weight8=float(input('请输入你想要的重量:'))
                print('你还需要点什么')
        elif shuiguo=='橘子':
            weight3=float(input('输入你想要的重量:'))
            jixu=input('西瓜？苹果？还是算了？:')
        else:
            print('好的，如果你愿意的话可以去别的地方转转!')




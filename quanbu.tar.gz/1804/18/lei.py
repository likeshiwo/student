class People:
    guoji='中国'
    def __init__(self):
        self.name='小明'
    def get_name(self):
        return self.name
    @classthod
    def get_guoji(cls):
        print('中国人')
print(People.guoji)
People.get_guoji()

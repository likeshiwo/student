f=open('yinhang.py','r')


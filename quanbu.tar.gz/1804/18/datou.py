class father:
    def __init__(self,name):
        self.xing=name
    def kaiche(self):
        print('会开车')
class son(father):
    def __init__(self,name):
        super().__init__(name)
    def kaiche(self):
        super().kaiche()
son=son('heh')
print(son.xing)
son.kaiche()

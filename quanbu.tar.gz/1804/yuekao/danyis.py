class Dog(object):
    __oob=None
    def __init__(self):
        pass
    def __new__(cls,*k):
        if cls.__oob==None:
            cls.__oob=object.__new__(cls)
        return cls.__oob
a=Dog()
b=Dog()
print(a)
print(b)

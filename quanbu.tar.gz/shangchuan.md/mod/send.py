def send():
    print('成功')

a=1
b=5
while a<=5:
    print('*'*a)
    a=a+1
while b>0:
    b=b-1
    print('*'*b)

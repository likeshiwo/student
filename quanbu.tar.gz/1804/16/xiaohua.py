class People:
    def __init__(self,name,age):
        self.__name=name
        self.age=age
    def mingzi(self,n):
        self.name=n
        return self.name
    def nianl(self):
        return self.age
    def __duanxin(self):
        print('发送成功')
    def fasong(self,m):
        if m=='老王':
            print('你TM别乱玩!')
        else:
            return self.__duanxin()
name=input('请输入你的名字:')
age=int(input('输入你的年龄:'))
xiaohua=People(name,age)
xiaohua.mingzi(name)
xiaohua.nianl()
name2=input('输入你的姓名:')
xiaohua.fasong(name2)

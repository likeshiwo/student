a=1
while b<10:
    a=a+1
    b=1
    while b<10:
        b=b+1
if b<10:
    print(a*b)



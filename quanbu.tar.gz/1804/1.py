print("what do you do？")
o=input()
print("hahaha，%s"%o)

passwd=input('请输入密码:')
if passwd==789:
    print('Welcome')
else:
    print('滚蛋')

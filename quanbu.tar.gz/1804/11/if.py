name=input('请输入用户名:')
passwd=input('请输入密码:')
if name=='like' and passwd=='789':
    print('欢迎进入李客的世界')
else:
    print('错误，3秒之后将会炸掉!!')

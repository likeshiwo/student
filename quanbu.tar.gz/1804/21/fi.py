def fil(day):
    n = 0
    a,b=0,1
    while n < day:
        a,b = b,a+b
        n += 1
        print(b)
fil(10)

try:
    feel=input('请输入要打开的文件:')
    f=open(feel,'r')
    print(f.read())
except (TypeError,NameError,FileNotFoundError):
    print('程序出现问题')



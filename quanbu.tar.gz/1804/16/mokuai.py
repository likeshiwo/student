def sengd():
    print('我成功啦 啊啊  ')
def ok():
    print('NICE 哦客 哈哈')
if __name__=='__main__':
    print('测试')
    sengd()
#all 限定能使用什么
#__all__=['sengd']


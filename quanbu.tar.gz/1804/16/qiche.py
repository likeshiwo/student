class Qiche():
    def __init__(self,name,color,lunzi):
        self.name=name
        self.color=color
        self.lunzi=lunzi
        self.money=0
    def moneay(self,m):
        self.money +=m
        if self.money>=5000:
            print('需要100天......')
        elif self.money>=10000:
            print('需要50天......')
        elif self.money>=20000:
            print('需要30天......')
        elif self.money>=50000:
            print('老板你想什么时候要都行!!')
        else:
            print('需要10年......')
    def __str__(self):
        return '%s制造成功，颜色为:%s,%s个轮子'% (self.name,self.color,self.lunzi)
car_name=input('请输入你制作汽车的名字:')
car_color=input('请输入你制作汽车的颜色:')
car_lunzi=input('请输入你要制作汽车的轮子:')
che=Qiche(car_name,car_color,car_lunzi)
car_money=int(input('请输入你欲支付的金额(钱越多做的越快!):'))
che.moneay(car_money)
print(che)

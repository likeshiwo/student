list=[{{'面积':'100平米','人口200w'}:'北京',{'面积':'60平米','人口':'150w'}:'上海'}]
for i in list():
    for a.b in i.items():
        for c.d in b.items():
            print(c,d,b)

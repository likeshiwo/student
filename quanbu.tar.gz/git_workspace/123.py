def oushu():
    for x in range(1,10):
        for y in range(1,x+1):
            print('%d*%d=%d'%(x,y,x*y),end='\t')
        print('\n')
suan=input('会不会99乘法表?')
if suan=='会':
    oushu()
else:
    print('不知道')

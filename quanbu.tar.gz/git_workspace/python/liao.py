name = input('告诉我，你的名字: ')
print('你好',name,'我叫斯塔克')
youage=int(input('你多大了？'))
if youage<20:
    print('哇!小鲜肉哦，我可以保护你呀！')
else:
    print('这么老了，还玩电脑？')
    print('回家种地把')

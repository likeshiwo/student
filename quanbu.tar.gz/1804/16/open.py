name1=input('请输入你要复制的文件名:')
afile=open(name1,'rb+')
a=afile.read()
p=name1.rfind('.')#右向左找到.所在的位置
name=name1[:p]#找到从开始到到p对应的位置
nameq=name1[p:]#找到从p往后对应的位置
bfile=open(name+'副本'+nameq,'w')
#c=bfile.write(a)
#b=open(name1,'r')
#ad=b.read()
#print(ad)
while True:
    c=afile.read(25)
    if len(c)==0:
        break
    bfile.write(c)
print(c)
afile.close
bfile.close

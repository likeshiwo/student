import os
name=input('输入删除的文件:')
os.remove(name)
print('删除成功!')

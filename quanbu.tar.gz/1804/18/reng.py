class Text1(object):
    def __init__(self):
        self.name='open'
    def chu(self,a,b):
        try:
            return a/b
        except Exception as r:
            if self.name=='open':
                print('错误,%s'% r)
            else:
                raise
t=Text1()
print(t.chu(2,5))


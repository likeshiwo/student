print('请输入1-150')
ren=int(input('请输入年龄:'))
if ren<=10:
    print('幼年')
elif ren<=20 and ren>=10:
    print('青年')
elif ren<=30 and ren>=20:
    print('中年')
elif ren<=40 and ren>=30:
    print('壮年')
elif ren<=60 and ren>=40:
    print('老年')
elif ren<=80 and ren>=60:
    print('怎么还没死')
elif ren<=100 and ren>=80:
    print('握襙！')
elif ren<=150 and ren>=100:
    print('不多比比你是真的牛逼')
else:
    print('再JB乱输老子垂死你')

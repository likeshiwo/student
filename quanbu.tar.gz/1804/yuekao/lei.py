class student:
    def __init__(self,name,age,cj):
        self.name=name
        self.age=age
        self.cj=cj
    def get_name(self):
        return self.name
    def get_age(self):
        return self.age
    def get_cj(self):
        return self.cj
lk=student('李客',19,[80,10,30])
print(lk.get_name())
print(lk.get_age())
print(max(lk.get_cj()))

class Anil:
    def __init__(self,name):
        self.name=name
    def run(self):
        print('奔跑')
class Dog(Anil):
    def __init__(self,name):
        Anil.__init__(self,name)
    def name2(self):
        print('我叫%s' % (self.name))
hei=Dog('小黑')
hei.name2()
hei.run()

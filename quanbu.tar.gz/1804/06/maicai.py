import random
print('Welcome！')
mai=input('我们这里有水果，蔬菜，海鲜，请问你需要什么？:')
if mai == '水果':
    print('你好，欢迎来到水果店！')
    print('西瓜3.5元/斤，苹果2元/斤，橘子6元/斤')
    shuiguo=input('你需要点什么？:')
        if shuiguo=='西瓜':
            xigua=float(input('输入你想要的重量:'))
            print('你还需要点什么？')
            jixu=input('苹果？橘子？还是算了？:')
                if jixu=='苹果':
                    pingguo=float(input('输入你想要的重量:'))
                    print('你还需要些什么?')
                    jixu=('橘子？还是算了？')
                        if jixu=='橘子':
                            juzi=float(input('输入你想要的重量:'))
                            money=3.5*xigua+6*juzi+2*pingguo
                            print('你本次一共需要支付:',money,'元')
                            print('谢谢你的光临!')
                        else:
                            money=3.5*xigua+2*pingguo
                            print('你本次一共需要支付:',money,'元')
                elif jixu=='橘子':
                    juzi=float(input('输入你想要的重量:'))
                    print('你还需要些什么？')
                    jixu=('苹果？还是算了？')
                        if jixu=='苹果':
                            pingguo=float(input('输入你想要的重量:'))
                            money=3.5*xigua+6*juzi+2*pingguo
                            print('你本次一共需要支付:',money,'元')
                            print('谢谢你的光临')
                        else:
                            money=3.5*xigua+6*juzi
                            print('你本次一共需要祝福:',money,'元')
                else:
                    money=xigua*3.5
                    print('你本次需要支付:',money,'元')
                    print('谢谢你的光临')
        elif shuiguo=='苹果':
            pingguo=float(input('输入你想要的重量:'))
            print('你还需要点什么?')
            jixu=input('西瓜？橘子？还是算了？:')
                if jixu=='橘子':
                    juzi=float(input('输入你想要的重量:'))
                    print('你还需要些什么？')
                    jixu=('西瓜？还是算了？')
                        if jixu=='西瓜':
                            xigua=float(input('输入你想要的重量:'))
                            money=2*pingguo+6*juzi+3.5*xigua
                            print('你本次一共需要支付:',money,'元')
                            print('谢谢你的光临')
                        else:
                            money=6*juzi+2*pingguo
                            print('你本次一共需要支付:',money,'元')
                            print('谢谢你的光临')
                elif jixu=='西瓜':
                    xigua=float(input('输入你想要的重量:'))
                    print('你还需要些什么？')
                    jixu=('橘子？还是算了？')
                        if jixu=='橘子':
                            juzi=float(input('输入你想要的重量:'))
                            money=3.5*xigua+2*pingguo+6*juzi
                            print('你本次一共需要支付:',money,'元')
                            print('谢谢你的光临')
                        else:
                            money=3.5*xigua+2*pingguo
                            print('你本次一共需要支付:',money,'元')
                            print('谢谢你的光临')
        elif shuiguo=='橘子':
            juzi=float(input('输入你想要的重量:'))
            jixu=input('西瓜？苹果？还是算了？:')
                if jixu=='西瓜':
                    xigua=float(input('输入你想要的重量:'))
                    print('你还需要些什么？')
                    jixu=('苹果？还是算了？')
                        if jixu=='苹果':
                            pingguo=float(input('输入你想要的重量:'))
                            money=3.5*xigua+6*juzi+2*pingguo
                            print('你本次一共需要支付:',money,'元')
                            print('谢谢你的光临')
                        else:
                            money=3.5*xigua+6*juzi
                            print('你本次一共需要支付:',money,'元')
                            print('谢谢你的光临')
                  elif jixu=='苹果':
                        pingguo=float(input('输入你想要的重量:'))
                        print('你还需要些什么？')
                        jixu=('西瓜？还是算了？')
                     if jixu=='西瓜':
                            xigua=float(input('输入你想要的重量:'))
                            money=3.5*xigua+6*juzi+2*pingguo
                            print('你本次一共需要支付:'money,'元')
                            print('谢谢你的光临')
                   else:
                         money=6*juzi+2*pingguo
                         print('你本次一共需要支付:',money,'元')

        else:
            print('好的，如果你愿意的话可以去别的地方转转!')
else:
    print('哦')



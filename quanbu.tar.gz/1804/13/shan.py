t=('zhangsan','wangwu','lisi','wulaowua')
print(t)
print('第三个是%s:'% t[3])
for i in t:
    print(i)


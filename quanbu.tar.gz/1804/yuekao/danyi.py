class Dog(object):
    __new_g=True
    def __init__(self,name):
        self.name=name
    def __new__(cls,*k):
        if cls.__new_g==True:
            cls.__new_g=object.__new__(cls)
            return cls.__new_g
huang=Dog('a')
hei=Dog('b')
print(huang)
print(hei)



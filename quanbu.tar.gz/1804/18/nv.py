class Diyi(object):
    __oob=None
    __init_a=True
    def __init__(self,name):
        if Diyi.__init_a==True:
            self.name=name
            Diyi.__init_a=False
    def __new__(cls,*k):
        if cls.__oob==None:
            cls.__oob=object.__new__(cls)
        return cls.__oob
li=Diyi('李某某')
jia=Diyi('贾某')
print(li.name)
print(jia.name)
print(id(li))
print(id(jia))

year=float(input('请输入年份:'))
if (year/4==0) and (year/100!=0):
    print('这年为润年')
elif year%400==0:
    print('这年为润年')
else:
    print('这年为平年')



def cc():
    print('cc')

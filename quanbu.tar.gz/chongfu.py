o=0
for a in range(1,5):
    for b in range(1,5):
        for x in range(1,5):
            print('%d%d%d'%(a,b,x))
            o=o+1
print(o)

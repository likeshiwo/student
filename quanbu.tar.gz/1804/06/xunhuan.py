a=10
while a>3:
    print('我比3小')
    a=a-1
print('结束')

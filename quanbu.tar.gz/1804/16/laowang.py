class Ren:
    def __init__(self,name,ph,qiang):
        self.name=name
        self.ph=ph
        self.qiang=qiang
    def __str__(self):
        return '姓名:%s,ph值为:%d,持有:%s,'% (self.name,self.ph,self.qiang)
    def zhuangdan(self):
        print('正在装弹夹......')
    def chouhen(self):
        print('你咬牙切齿心中充满了仇恨.....')
    def kaiqiang(self):
        print('哦!my god,你开抢了')
    def look(self):
        print('你看到,%s 兴高采烈的站在门前聊天'% self.name)
    def xue(self):
        print('%s 胸口中了一枪!!'% self.name)
    def si(self):
        print('%s 死了，带着满脸的疑惑和不解......'% self.name)


class Background:
    def begin(self):
        print('一场悲剧即将发生.....')
    def qunzong(self):
        print('由于你的举动，群众发起暴乱....')
    def si_huanjing(self):
        print('天空下起了雨,你看着面前躺在血池里的人.....')


class Zidan:
    def __init__(self,name,shanghai):
        self.name=name
        self.shanghai=shanghai
    def __str__(self):
        return '该子弹为:%s,杀伤力为:%d'% (self.name,self.shanghai)

class Danjia:
    def __init__(self,zidan):
        self.zidan=zidan
    def cundan(self):
        print('当前正在装弹，一共%d个'% self.zidan)
    def qudan(self):
        self.zidan-=1
        print('剩余%d,请珍惜子弹!' % self.zidan)

name=input('请输入你的名字:')
qiang=input('请输入你的枪械:')
you=Ren(name,100,qiang)
ren=Background()
ren.begin()
print(you)
laowang=Ren('老王',100,'无')
laowang.look()
you.chouhen()
you.zhuangdan()
you_zidan=int(input('请输入你弹夹中含有的子弹:'))
danjia=Danjia(you_zidan)
danjia.cundan()
zidan=input('请输入你要填装什么类型的子弹:')
zidan=Zidan(zidan,100)
print(zidan)
you.kaiqiang()
danjia.qudan()
laowang.xue()
laowang.si()
ren.qunzong()
ren.si_huanjing()


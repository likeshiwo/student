class gtq:
    def __init__(self,name,money):
        self.name=name
        self.money=money

    def set(self,new_money):
        if new_money>self.money:
            self.money=new_money
            print(new_money)
        else:
            print('呵呵')
    def kan(self,you_name):
        if you_name=='朋友':
            print('我的工资是10000000')
        elif you_name=='老爹':
            print('我的工资是:%d'% self.money)
        elif you_name=='媳妇':
            print('我的工资是1')
gtq=gtq('光头强',10000)
gtq.set(1000000)
gtq.kan('老爹')

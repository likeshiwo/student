import random
pc=random.randint(1,4)
paler=input('请输入石头/剪刀/布:')
a='石头'
b='剪刀'
c='布'

if pc == 1 and paler == '布' or pc == 2 and paler == '石头' or pc == 3 and paler == '剪刀':
    print('你赢了')
elif pc == 1 and paler == '剪刀' or pc == 2 and paler == '剪刀' or pc == 3 and paler == '石头':
    print('你输了')
elif pc == 1 and paler == '石头' or pc == 2 and paler == '剪刀' or pc == 3 and paler == '布':
    print('平局')
else:
    print('输入错误')

class Car(object):
    __instace=None
    def __init__(self,name):
        self.name=name
    def __new__(cls,*k):
        if cls.__instace==None:
            cls.__instace=object.__new__(cls)
        return cls.__instace
c1=Car('c1')
c2=Car('c2')
print(id(c1))
print(id(c2))

a=360
b=24
c=60
d=60
e=a*b*c*d
print('一年有:',e,'秒')



class House:
    def __init__(self,daxiao,dizhi):
        self.daxiao=daxiao
        self.dizhi=dizhi
        self.l=[]
    def __str__(self):
        return '你房子的大小是:%s,地址位于:%s,购买的家具有;%s'% (self.daxiao,self.dizhi,str(self.l))
    def add_l(self,l):
        if int(self.daxiao)>=int(l.daxiao):
            self.daxiao-=l.daxiao
            print(self.l.append(l.name))
        else:
            print('呵呵')
class bed:
    def __init__(self,name,daxiao):
        self.name=name
        self.daxiao=daxiao
    def __str__(self):
        return '你成功购买:%s,大小为:%s'% (self.name,self.daxiao)
jia=House(20000,'洛阳')
chuang=bed('双人床',100)
xiao=bed('婴儿床',200)
jia.add_l(xiao)
jia.add_l(chuang)
print(chuang)
print(jia)




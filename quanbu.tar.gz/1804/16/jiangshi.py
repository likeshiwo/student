class Zombie:
    def __init__(self,name,ph,color):
        self.name=name
        self.ph=ph
        self.color=color
    def __str__(self):
        return self.name+'僵尸出现了,闪着'+self.color+'的光芒，有着'+self.ph+'血量'
    def eat(self):
        print('%s 僵尸咋横在努力吃屎......'% self.name)
    def run(self):
        print('%s 僵尸跑起来.......'% self.name)
jiangshi=Zombie('普通僵尸','50','黑色')
jiangshi.eat()
jiangshi.run()
print(jiangshi)

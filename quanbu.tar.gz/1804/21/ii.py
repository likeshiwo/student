class People:
    def __init__(self):
        self._moeny=1
    def set_money(self):
        return get_money
    def set_money(self,value):
        self._money=value
p=People()
print(p.money)
p.money=999
print(p.money)


class Tudou():
    def __init__(self):
        self.name='土豆丝'
        self.time=0
        self.lista=[]
    def chao(self,m):
        self.time +=m
        if self.time>=10:
            print('炒烂了,')
        elif self.time>=7:
            print('炒焦了,')
        elif self.time>=5:
            print('炒的正好,真香!')
        elif self.time>=3:
            print('还没熟呢!' )
        else:
            print('哦！肉丝，那是生的土豆')
    def Add(self,lista):
        self.lista.append(lista)
    def __str__(self):
        for i in self.lista:
            return '当前的土豆丝是:%s,当前土豆丝的状态是:%s'% (self.name,i)
tudou=Tudou()
print(tudou.name)
liao=input('输入你想加入的调料:')
you=int(input('输入你想炒的时间:'))
tudou.chao(you)
tudou.Add(liao)
print(tudou)

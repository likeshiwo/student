class Suan(object):
    __init_name=True
    __new_oob=False
    def __init__(self,name):
        if Suan.__init_name==True:
            self.name=name
            Suan.__init_name=None
    def __new__(cls,*k):
        if cls.__new_oob==False:
            cls.__new_oob=object.__new__(cls)
        return cls.__new_oob
    def jia(self,x,y):
        return x+y
    def jian(self,x,y):
        return x-y
    def cheng(self,x,y):
        return x*y
    def chu(self,x,y):
        return x/y
class People(Suan):
    def ji_suan(self,a,b,fuhao):
        if fuhao=='+':
            return super().jia(x,y)
        elif fuhao=='-':
            return super().jian(x,y)
        elif fuhao=='*':
            return super().cheng(x,y)
        elif fuhao=='/':
            return super().chu(x,y)
caom=People('天河计算机')
try:
    p=int(input('输入数字:'))
    o=input('输入运算符号:')
    s=int(input('输入数字:'))
    r=caom.ji_suan(x,y,o)
    print(r)
except Exception as i:
    print(i)


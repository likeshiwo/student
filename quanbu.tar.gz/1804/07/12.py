s=input()
if s==1:
    print('asd')
elif s==2:
    print('szxcv')
else:
    print('zxc')

class People_Like:
    def __init__(self):
        self.__age=19
    def set(self,n):
        if n == '李客':
            print('我今年%d岁'% self.__age)
        else:
            print('你无需知道')
    def get(self,b):
        if b == '李客':
            age2=input('输入你要修改的年龄:')
            age2=self.__age
            print('保存成功')
        else:
            print('权限不够!')
class Zhangsan_Like(People_Like):
    def __init__(self):
        self.__money=100
    def property(self,a):
        if a == '李客':
            print('我有%d元'% self.__money)
            num=input('需要修改么(yes/no)')
            if num == 'yes':
                money2=input('输入你想修改后的钱:')
                self.__money=money2
                print('修改成功')

        else:
            print('无权访问')

like=People_Like()
name1=input('请输入你的名字:')
like.set(name1)
name2=input('请输入你的名字')
like.get(name2)
zhangsan=Zhangsan_Like()
name=input('请输入你的名字')
zhangsan.property(name)




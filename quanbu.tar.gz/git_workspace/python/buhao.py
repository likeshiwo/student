print('死亡如风常伴吾身')
name=input('说出这个英雄:')
print('你说对了，小东西不简单啊')
name=input('告诉我你的名字:')
print('你好',name,'这个名字...唉，难怪你长这样')


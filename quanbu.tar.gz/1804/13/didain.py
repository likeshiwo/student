dic = {'姓名':'李客','绰号':'别天神','职业':'超级英雄','地址':'地球'}
print(dic)
l=[]
name=input('请输入公司:')
dic['name']=name
print(dic)
l.append(dic)
print(l)

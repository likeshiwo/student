'''
f=open('李客','w')
f.write('        侠客行\n')
f.write('赵客缦胡缨，吴钩霜雪明\n')
f.write('银鞍照白马，飒沓如流星\n')
f.write('十步杀一人，千里不留行\n')
f.write('事了拂衣去，深藏身与名\n')
f.write('闲过信陵饮，脱剑膝前横\n')
f.write('将炙啖朱亥，持觞劝侯嬴\n')
f.write('三杯吐然诺，五岳倒为轻\n')
f.write('眼花耳热后，意气素霓生\n')
f.write('救赵挥金锤，邯郸先震惊\n')
f.write('千秋二壮士，烜赫大梁城\n')
f.write('纵死侠骨香，不惭世上英\n')
f.write('谁能书阁下，白首太玄经\n')
f.write('                    —— 李客\n')
f=open('李客','rb+')
ok=f.readlines()
'''
'''
p=f.tell()#获得当前位置下标
p=f.seek()#移动下标
f=open('李客','w')
for i in ok:
    print(i[0:-1]+'。')
f=open('李客','rb+')
f.seek(2,0)#从当头开始
print('文件读取的当前位置是:%d'% f.tell())
f.seek(2,1)#充当前的位置开始:
print('文件向右偏移的位置是:%d'% f.tell())
f.seek(6,2)#从文件末尾开始
print('文件向右偏移的位置是:%d'% f.tell())
f.close()
'''
#定位seek
f=open('tangshi','w')
f.write('窗前明月光\n')
f.write('亦是地上霜\n')
f.write('抬头望明月\n')
f.write('低头思故乡\n')
f.close
f=open('tangshi','r')
c = f.readline()
p = f.tell()
print('读取的第1行内容是:%s'% c)
print('读取的第1行之后的游标位置是:%d'% p)
c = f.readline()
p = f.tell()
print('读取的第2行内容是:%s'% c)
print('读取的第2行之后的游标位置是:%d'% p)
c = f.readline()
p = f.tell()
print('读取的第3行内容是:%s'% c)
print('读取的第3行之后的游标位置是:%d'% p)
c = f.readline()
p = f.tell()
print('读取的第4行内容是:%s'% c)
print('读取的第4行之后的游标位置是:%d'% p)
f=open('tangshi','rb+')
f.seek(5,0)
print(f.readline())




'''
print('文件名是:%s'% f.name)
print('文件是否已经关闭:%s'% f.closed)
print('文件的访问模式是:%s'% f.mode)
'''

'''
import os
os.rename('原名','现名')


import os
os.remove('要删除的文件名')
'''


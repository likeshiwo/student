def sige(x,y):
    a=x+y
    b=x-y
    c=x*y
    d=x/y
    print(a,b,c,d)
sige(5,1)

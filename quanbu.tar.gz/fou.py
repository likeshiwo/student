import random
pc=random.randint(1,100)
print('游戏')
i=0
while True:
    user=int(input('输入'))
    i=i+1
    if user < pc:
        print('小')
    elif user > pc:
        print('大')
    else:
        print('对了')
        break
print('你猜了%d'% i)
if i <= 5:
    print('可以')
else:
    print('海鲜')

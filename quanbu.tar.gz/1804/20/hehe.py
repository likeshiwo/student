for a in range(a,b):
    for b in range(1,y+1):
    print('%d*%d=%d'% (a,y,a*y))
    a=a+1

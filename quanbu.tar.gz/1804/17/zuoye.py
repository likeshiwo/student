student=[]
cj={}
class Student:
    def __init__(self,name,age,sex):
        self.name=name
        self.age=age
        self.sex=sex
    def gaiming(self,na):
        self.name=na
    def gainian(self,ag):
        self.age=ag
    def gaixing(self,se):
        self.sex=se

    def add(self):
        student.append(self.name)

    def __str__(self):
        return '姓名:'+self.name+',年龄:'+self.age+',性别:'+self.sex
class Banji(Student):
    def __init__(self,name,bianhao):
        self.name=name
        self.bianhao=bianhao
    def gaibanren(self,ban):
        self.name=ban
    def gaiban(self,hao):
        self.bianhao=hao
    def __str__(self):
        a=''
        for i in student:
            a+=i+','
        return '班主任:'+self.name+'，班级:'+self.bianhao+'，班级学生:'+a

class Cj:
    def __init__(self,yw,sx,yy):
        self.yw=yw
        self.sx=sx
        self.yy=yy
    def addcj(self,k,v):
        cj[k]=v
    def chaxun(self,n):
        if n=='数学':
            print(self.sx)
        elif n=='语文':
            print(self.yw)
        elif n=='英语':
            print(self.yy)
        else:
            print('成绩不存在!')
    def __set_cj(self,m,f):
        if m=='数学':
            self.sx=f
        elif m=='语文':
            self.yw=f
        elif m=='英语':
            self.yy
    def __str__(self):
        return '数学:'+self.sx+'\n语文:'+'\n英语:'+self.yy


name=input('输入第一位学生的姓名:')
age=input('输入第一位学生的年龄:')
sex=input('输入第一位学生的性别:')
xiaoming1=Student(name,age,sex)
xiaoming1.add()
cj1=input('输入语文成绩:')
cj2=input('输入数学成绩:')
cj3=input('输入英语成绩:')
xiaoming=Cj(cj1,cj2,cj3)
xiaoming.addcj('语文',cj1)
xiaoming.addcj('数学',cj2)
xiaoming.addcj('英语',cj3)
print(xiaoming1)
print(xiaoming)



name_jun=input('输入第二位学生的姓名:')
age_jun=input('输入第二位学生的年龄:')
sex_jun=input('输入第二位学生的性别:')
xiaojun1=Student(name_jun,age_jun,sex_jun)
xiaojun1.add()
xiaojuncj1=input('输入语文成绩:')
xiaojuncj2=input('输入数学成绩:')
xiaojuncj3=input('输入英语成绩:')
xiaojun=Cj(xiaojuncj1,xiaojuncj2,xiaojuncj3)
print(xiaojun1)
print(xiaojun)



name_wang=input('输入第三位学生的姓名:')
age_wang=input('输入第三位学生的年龄:')
sex_wang=input('输入第三位学生的性别:')
xiaowang1=Student(name_wang,age_wang,sex_wang)
xiaowang1.add()
cj1_wang=input('输入语文成绩:')
cj2_wang=input('输入数学成绩:')
cj3_wang=input('输入英语成绩:')
xiaowang=Cj(cj1_wang,cj2_wang,cj3_wang)
print(xiaowang1)
print(xiaowang)




name_hua=input('输入第四位学生的姓名:')
age_hua=input('输入第四位学生的年龄:')
sex_hua=input('输入第四位学生的性别:')
xiaohua1=Student(name_hua,age_hua,sex_hua)
xiaohua1.add()
hua_cj1=input('输入语文成绩:')
hua_cj2=input('输入数学成绩:')
hua_cj3=input('输入英语成绩:')
xiaohua=Cj(hua_cj1,hua_cj2,hua_cj3)
print(xiaohua1)
print(xiaohua)



name_cui=input('输入第五位学生的姓名:')
age_cui=input('输入第五位学生的年龄:')
sex_cui=input('输入第五位学生的性别:')
xiaocui1=Student(name_cui,age_cui,sex_cui)
xiaocui1.add()
cui_cj1=input('输入语文成绩:')
cui_cj2=input('输入数学成绩:')
cui_cj3=input('输入英语成绩:')
xiaocui=Cj(cui_cj1,cui_cj2,cui_cj3)
print(xiaocui1)
print(xiaocui)



name_li=input('输入第六位学生的姓名:')
age_li=input('输入第六位学生的年龄:')
sex_li=input('输入第六位学生的性别:')
xiaoli1=Student(name_li,age_li,sex_li)
xiaoli1.add()
li_cj1=input('输入语文成绩:')
li_cj2=input('输入数学成绩:')
li_cj3=input('输入英语成绩:')
xiaoli=Cj(li_cj1,li_cj2,li_cj3)
print(xiaoli1)
print(xiaoli)


name_fang=input('输入第七位学生的姓名:')
age_fang=input('输入第七位学生的年龄:')
sex_fang=input('输入第七位学生的性别:')
xiaofang1=Student(name_fang,age_fang,sex_fang)
xiaofang1.add()
fang_cj1=input('输入语文成绩:')
fang_cj2=input('输入数学成绩:')
fang_cj3=input('输入英语成绩:')
xiaofang=Cj(fang_cj1,fang_cj2,fang_cj3)
print(xiaofang1)
print(xiaofang)



name_gang=input('输入第八位学生的姓名:')
age_gang=input('输入第八位学生的年龄:')
sex_gang=input('输入第八位学生的性别:')
xiaogang1=Student(name_gang,age_gang,sex_gang)
xiaogang1.add()
gang_cj1=input('输入语文成绩:')
gang_cj2=input('输入数学成绩:')
gang_cj3=input('输入英语成绩:')
xiaogang=Cj(gang_cj1,gang_cj2,gang_cj3)
print(xiaogang1)
print(xiaogang)


name_zhao=input('输入第九位学生的姓名:')
age_zhao=input('输入第九位学生的年龄:')
sex_zhao=input('输入第九位学生的性别:')
xiaozhao1=Student(name_zhao,age_zhao,sex_zhao)
xiaozhao1.add()
zhao_cj1=input('输入语文成绩:')
zhao_cj2=input('输入数学成绩:')
zhao_cj3=input('输入英语成绩:')
xiaozhao=Cj(zhao_cj1,zhao_cj2,zhao_cj3)
print(xiaozhao1)
print(xiaozhao)


hong_name=input('输入第十位学生的姓名:')
hong_age=input('输入第十位学生的年龄:')
hong_sex=input('输入第十位学生的性别:')
xiaohong1=Student(hong_name,hong_age,hong_sex)
xiaohong1.add()
hong_cj1=input('输入语文成绩:')
hong_cj2=input('输入数学成绩:')
hong_cj3=input('输入英语成绩:')
xiaohong=Cj(hong_cj1,hong_cj2,hong_cj3)
print(xiaohong1)
print(xiaohong)


banji=Banji('刘斌','1804')
while True:
    print('*'*50)
    print('查询班级输入1')
    print('查询学生输入2')
    print('修改姓名输入4')
    print('修改性别输入5')
    print('修改年龄输入6')
    print('修改数学输入7')
    print('修改英语输入8')
    print('修改语文输入9')
    print('*'*50)
    shuruba=int(input('请输入:'))
    if shuruba==1:
        print(banji)
    elif shuruba==2:
        name_xs = input('请输入你要查询的名字:')
        for name in student:
            if name_xs==xiaoming1:
                goname=input('若想修改输入w,不修改输入q:')
                xiaoming1.gaiming(q)
                print(xiaoming1)
                print(xiaoming)
            elif name_xs==xiaojun1:
                goname=input('若想修改输入w,不修改输入q:')
                print(xiaojun1)
                print(xiaojun)
            elif name_xs==xiaowang1:
                goname=input('若想修改输入w,不修改输入q:')
                print(xiaowang1)
                print(xiaowang)
            elif name_xs==xiaohua1:
                goname=input('若想修改输入w,不修改输入q:')
                print(xiaohua1)
                print(xiaohua)
            elif name_xs==xiaocui1:
                goname=input('若想修改输入w,不修改输入q:')
                print(xiaocui1)
                print(xiaocui)
            elif name_xs==xiaoli1:
                goname=input('若想修改输入w,不修改输入q:')
                print(xiaoli1)
                print(xiaoli)
            elif name_xs==xiaofang1:
                goname=input('若想修改输入w,不修改输入q:')
                print(xiaofang1)
                print(xiaofang)
            elif name_xs==xiaogang1:
                goname=input('若想修改输入w,不修改输入q:')
                print(xiaogang1)
                print(xiaogang)
            elif name_xs==xiaozhao1:
                goname=input('若想修改输入w,不修改输入q:')
                print(xiaozhao1)
                print(xiaozhao)
            elif name_xs==xiaohong1:
                goname=input('若想修改输入w,不修改输入q:')
                print(xiaohong1)
                print(xiaohong)
            else:
                print('本班无此人.....')
    else:
        break






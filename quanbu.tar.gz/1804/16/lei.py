class people:
    def eat(self):
        print('吃饭')
    def word(self):
        print('工作')
    def banzhuan(self):
        print('日常搬砖')
    def shuatu(self):
        print('没日没夜的刷图')
    def shenyuan(self):
        print('天天刷深远')
    def introduce():
        print('我叫%s，今年%d'% self.like,self.cuikang)
class dongwu:
    def eat(self):
        print('吃东西')
    def dajia(self):
        print('小猫正在打架')
    def sleep(self):
        print('小猫开始睡觉了')
    def introduce(self):
        print('我叫%s，我是%s'% self.name,self.close)
like=people()
like.age=19
like.name='李客'
like.introduce()
cukang=people()
cuikang.age=18
cuikang.name='催康'
cuikang.introduce()
mao=dongwu()
mao.name='红猫'
mao.close='黑色'
mao.introduce()
mao=dongwu()
mao.name='Tom'
mao.close='蓝色'
mao.introduce()


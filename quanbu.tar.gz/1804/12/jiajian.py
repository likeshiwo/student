def jia(a,b,c):
    return a+b-c
x=int(input('请输入第一位数:'))
y=int(input('请输入第二位数:'))
f=int(input('请输入第三位数:'))
s = jia(x,y,f)
print('答案是:',s)


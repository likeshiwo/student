class Duck:
    def zou(self):
        print('走路.....')
    def swim(self):
        print('游泳......')
class People:
    def zou(self):
        print('跑步......')
    def swim(self):
        print('不停的游泳')
def hiei(s):
    s.zou()
    s.swim()
duck=Duck()
people=People()
hiei(people)

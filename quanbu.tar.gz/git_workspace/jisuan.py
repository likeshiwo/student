def jia(a,b):
    return a+b
    print(s)
def jian(a,b):
    return a-b
    print(d)
def cheng(a,b):
    return a*b
    print(f)
def chu(a,b):
    return a/b
    print(g)
q = int(input('请输入第一个数字:'))
e = input('请输入符号:(+  -  *  /)')
w = int(input('请输入第二个数组:'))
if e=='+':
    s=jia(q,w)
elif e=='-':
    d = jian(q,w)
elif e=='*':
    f = cheng(q,w)
elif e=='/':
    g = chu(q,w)
else:
    print('在乱输，老子锤死你!')



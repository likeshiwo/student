l=[]
for i in range(1,101):
    if i%3 and i%5 ==0:
        l.append(i)
print(l)

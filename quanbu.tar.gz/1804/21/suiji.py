import random
import time
for i in range(2):
    a=random.randnint(1,6)
    b=random.randint(1,8)
    for y in range(2):
        q=random.randint(1,6)
        w=random.randint(1,8)
print('第一位:请第',a,'列','第',b,'行上台')





class Dog:
    def game(self):
        print('在地上玩')
class Xiaotian(Dog):
    def game(self):
        print('在天上玩耍')
class People:
    def play(self,dog):
        print('和',dog.game())
d=Dog()
p=People()
p.play(d)

l=(i for i in range(1,101))
next(l)
iter(l)
def li(day):
    n=0
    a,b=0,1
    while n<day:
        a,b=b,a+b
        n+=1
        print(b)
li(10)

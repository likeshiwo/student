f = open('diyi.py','r')

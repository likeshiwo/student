a=1
b=2
while b>0:
    print(' '*b,'*'*a)
    a=a+1
    b=b-1



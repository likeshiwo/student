name='李客'
agage=19
frome='河南洛阳'
xueli='高中'
school='北京财经学园'
print('大家好，我叫:',name,'今年:',agage,'来自:',frome,'学历:',xueli,'现读学校:',school)

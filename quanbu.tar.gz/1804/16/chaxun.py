import sys
class people:
    def __init__(self,name,age):
        self.name=name
        self.age=age
class Worker:
    def __init__(self,name,age):
        self.name=name
        self.age=age
xiaohua01=people('小花',20)
xiaohua03=xiaohua01
xiaohua02=xiaohua01
print(sys.getrefcount(xiaohua01))
print(isinstance(xiaohua01.people))

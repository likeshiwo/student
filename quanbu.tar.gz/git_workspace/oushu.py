def jiafa():
    b=0
    for a in range(1,101,1):
        if a%2==0:
            b=b+a
    print(b)
jiafa()



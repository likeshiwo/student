class Chinken:
    def __init__(self):
        self.name='鸡翅'
        self.time=0
        self.list=[]
    def kao(self,m):
        self.time +=m
        if self.time>=8:
            self.name='烤焦的鸡翅'
        elif self.time>=6:
            self.name='考过的鸡翅'
        elif self.time>=4:
            self.name='鸡翅正好'
        elif self.time>=2:
            self.name='鸡翅不熟'
        else:
            self.time='鸡翅不熟'
jichi01=Chinken()
print(jichi01.name)
jichi01.kao(2)
print(jichi01.name)
jichi01.kao(2)
print(jichi01.name)
jichi01.kao(2)
print(jichi01.name)

a=['人生苦短,我用python,life is short']
print(a.count('p'))
print(a.count('i'))
print(a.find('s'))


'''
def counter(start=0):
    def incr():
        nonlocal start
        start+=1
        return start
    return incr
cl = counter(1)
print('cl = %d' % cl())
'''
def wai(x):
    def nei(a,b):
        print('y=%d*%d+%d' % (a,x,b))
        y=a*x+b
        return y
    return nei
ok=wai(1)
print(ok(3,2))

digui(n)
    return n*4*3*2*1
dier(x)
s=dier(5)
print(s)

print('帐号123')
print('密码789')
a=1
while a<=4:
    b=input('帐号:')
    c=input('密码:')
    if b=='123' and c=='789':
        print('欢迎')
    else:
        print('错误')
    a=a+1


for a in range(1,100):
    if a % 2!=0:
        print(a)

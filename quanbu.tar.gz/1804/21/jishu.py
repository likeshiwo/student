y=0
for i in range(1,100):
    if i%2==0:
        pass
    else:
        y=i+i
print(y)

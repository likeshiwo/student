import jia
jia.quanbu()

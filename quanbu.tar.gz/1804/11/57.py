for a in range(1,5001):
    if a%5==0 and a%7==0:
        print(a)
    continue

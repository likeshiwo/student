def zou():
    print('呵呵')

name=input('你的名字是:')
print("输出的内容")
qwe=input('请输入内容:')
if qwe=='不好':
    print('输入的内容')
elif qwe=='xx':
    print('入')
else:
    print('输入内容')

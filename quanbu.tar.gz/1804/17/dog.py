class Dog:
    def __init__(self,name,age):
        self._name=name
        self.age=age
    def set_name(self,n):
        self.name=n
    def get_name(self,m):
        if m=='主人':
            print('姓名:%s,年龄:%d'% (self.name,self.age))
        else:
            print('..')
dog=Dog('小哈',18)
dog.set_name('速度')
name=input('请输入:')
dog.get_name(name)

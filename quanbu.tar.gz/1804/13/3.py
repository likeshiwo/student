a=[]
while True:
    name=input('请输入姓名,不输入q:')
    a.append(name)
    if name=='q':
        break
print('第三个人是:%s'% a[3])
print('第五个人是:%s'% a[5])
print('第八个人是:%s'% a[8])
print('第十个人是:%s'% a[10])
print(a.sort())
print(a.sort(reverse=True))
print(a.pop)
print(a.pop(8))
list2('小明')
print(list2.extend(a))




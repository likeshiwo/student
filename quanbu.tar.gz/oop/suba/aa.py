def aa():
    print('aa')

def jsq(*k):
    def wai(fun):
        def nei(*k):
            print('传入的参数是:',*k)
            print('调用成功!')
            fun(*k)
        return nei
    return wai
@jsq(1,2,3,4,5,6)
def foo(*k):
    print('=====嘿嘿=====')
foo()

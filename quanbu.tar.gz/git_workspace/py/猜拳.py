import random
userbegin='go'
while userbegin=='go':
    print('我们玩个游戏把!')
    pc=random.randint(1,3)
    user=input('1为石头/2为剪刀/3为布 (不想玩输入q):')
    if user =='q':
        userbegin='q'
    elif pc==1:
        print('斯塔卡出了:石头')
    elif pc==2:
        print('斯塔克出了:剪刀')
    elif pc==3:
        print('斯塔克出了:布')
    elif user==1:
        print('你出了:石头')
    elif user==2:
        print('你出了:剪刀')
    elif user==3:
        print('你出了:布')
    elif user==1 and pc==2 or user==2 and pc==3 or user==3 and pc==1:
        print('如果我俩角色互换，我会让你知道什么叫残忍！')
    elif user==2 and pc==1 or user==3 and pc==2 or user==1 and pc==3:
        print('我渴望有价值的对手!')
    else:
        print('无形之刃，最为致命!')


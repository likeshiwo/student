l=[]
for i in range(3):
    num=input('输入数字:')
    l.append(num)
l.sort()
print(l)

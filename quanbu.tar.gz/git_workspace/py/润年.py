year=float(input('请输入需要计算的年龄:'))
if year%4==0 and year%100!=0:
    print('该年为润年')
elif year%400==0:
    print('该年为润年')
else:
    print('该年为平年')

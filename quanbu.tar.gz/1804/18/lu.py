class ma:
    def pao(self):
        print('跑得快....')
    def jiao(self):
        print('叫')
class lu:
    def man(self):
        print('走的慢....')
    def jiao(self):
        print('不叫')
class luozi(ma,lu):
    pass
    def jiao(self):
        print('欢快的叫着')
luozi1=luozi()
luozi1.pao()
luozi1.man()
luozi1.jiao()
print(luozi.__mro__)

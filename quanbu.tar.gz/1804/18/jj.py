def add(a,b):
    return a+b
def div(a,b):
    return a/b
if __name__='__main__':
    c=add(3,4)
    print('测试结果是:%d'% c)

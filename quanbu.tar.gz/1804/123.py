y=0
for x in range(1,101,1):
    y=y+2
    if x%2==0:
        print(x+y)

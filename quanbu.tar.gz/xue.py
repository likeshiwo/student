import random
import time
while True:
    xue=random.randint(1,300)
    print(' '*xue,'$')
    print(' '' '*xue,'$')
    print('  '' '*xue,'$')
    print('   '' '*xue,'$')
    print('    '' '*xue,'$')
    print('       '' '*xue,'$')
    print('         '' '*xue,'$')
    print('           '' '*xue,'$')
    print('                '' '*xue,'$')
    print('                 '' '*xue,'$')
    print('                '' '*xue,'$')
    print('                    '' '*xue,'$')
    time.sleep(1)

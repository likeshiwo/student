class Car:
    def __init__(self,name):
        self.name=name
    def pao(self):
        return '飞奔的汽车:'
class dazong(Car):
    def pao(self):
        return '大众摩托，风驰天下'
class baoma(Car):
    def pao(self):
        return '敢问月下马? 社会我宝马!'
class benchi(Car):
    def pao(self):
        return '奔驰自行车，骑着停不了'
class People:
    def __init__(self,name):
        self.name=name
    def kaiche(self,d):
        print('%s在开着'% self.name,'他是:',d.pao(),'在泡妞')
car=Car('普通')
dazong=dazong('大众')
baoma=baoma('宝马')
benchi=benchi('奔驰')
people=People('李客')
people.kaiche(baoma)
people=People('海龙')
people.kaiche(dazong)
people=People('加盟号')
people.kaiche(benchi)


class Ren:
    def __init__(self,name):
        self.name=name
        self.f=open('name.txt','w')

    def get_name(self,m):
        f=open('name.txt','w')
        f.write(m)
        f=open('name.txt','r')
        s=f.read()
        if len(s)!=0:
            self.name=s
            print('保存成功，姓名:%s'% self.name)
        else:
            return self.name

    def __del__(self):
        self.f.write(self.name)
        self.f.close()
        print('=====================')



        print('================')
lk=Ren('李客')
name=input('当前的姓名是:李客,若修改请输入新名字:')
lk.get_name(name)




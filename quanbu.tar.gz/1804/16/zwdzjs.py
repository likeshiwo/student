class xrk:
    def __init__(self,name):
        self.name=name
    def __str__(self):
        return '姓名:'+self.name+',特点：无'
    def guang(self):
        print('%s 开始放阳光.....'% self.name)
class wd:
    def __init__(self,name,color,soft,ph):
        self.name=name
        self.color=color
        self.soft=soft
        self.ph=ph
    def __str__(self):
        return '姓名:'+self.name+',颜色:'+self.color+',发型:'+self.soft+',血量:'+self.ph
    def fapao(self):
        print('发炮......')
    def yaotou(self):
        print('摇头......')
class jg():
    def __init__(self,name,ph,sort):
        self.name=name
        self.ph=ph
        self.sort=sort
    def __str__(self):
        return '姓名:'+self.name+',血量:'+self.ph+',类型'+self.sort
    def zudang(self):
        print('阻挡.......')
class jiangshi():
    def __init__(self,name,color,ph,sort,sudu):
        self.name=name
        self.color=color
        self.ph=ph
        self.sort=sort
        self.sudu=sudu
    def __str__(self):
        return'姓名:'+self.name+',颜色:'+self.color+',血量:'+self.ph+',类型:'+self.sort+',速度:'+self.sudu
    def zou(self):
        print('走......')
    def pao(self):
        print('跑跳......')
    def chi(self):
        print('吃......')
    def si(self):
        print('死了!!??')
def bisha(items):
    items.pao()
    items.chi()
    items.pao()
    items.chi()
    items.chi()
xrk=xrk('向日葵')
print(xrk)
xrk.guang()
wandou=wd('豌豆','紫色','杀马特','200')
print(wandou)
wandou.fapao()
jianguo=jg('坚果','200','畸形')
jiangshi=jiangshi('狂暴僵尸','黑色','500','强攻','150')
print(jiangshi)
jiangshi.zou()
jiangshi.pao()
print(jianguo)
jianguo.zudang()
jiangshi.chi()
bisha(jiangshi)

wandou.yaotou()


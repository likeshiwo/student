name='李客'
agage=19
print('我叫:',name,'今年:',agage)

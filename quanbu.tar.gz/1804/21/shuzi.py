x=0
for i in range(1,5):
    for a in range(1,5):
        for y in range(1,5):
            if i!=a and i!=y and a!=y:
                x+=1
                print(i,a,y)
print(x)

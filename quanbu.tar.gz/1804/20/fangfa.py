def jia(n):
    if n>=1:
        return = n*jia(n-1)
    else:


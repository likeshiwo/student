a=[]
while True:
    name=input('请输入姓名不输入点q:')
    a.append(name)
    if name=='q':
        break
print(a)
print('第三位是:%s'% a[3])
print('第五位是:%s'% a[5])
print('第八位是:%s'% a[8])
print('第十位是:%s'% a[10])
a.sort()
print(a)
# 倒序 打印
a.sort(reverse=True)
print(a)
#弹出最后一个 同学打印
print(a.pop())
#删除第8人 打印

def quanbu():
    import 佛祖镇楼
    佛祖镇楼.fozu()
    def jia(a,b,c):
        return a+b+c
    num=int(input('请输入第一位数:'))
    num2=int(input('请输入第二位数:'))
    num3=int(input('请输入第三为数:'))
    s = jia(num,num2,num3)
    def jun(a,b,c):
        return (a+b+c)/3
    g = jun(num,num2,num3)
    print('3位数的和是:%d,平均数是:%d'%(s,g))

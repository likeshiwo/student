price=int(input('充值:'))
while price<150:
    print('这点钱能干什么？没收了继续充')
    price=price+1
    print('可以了，算你还有点钱')
    print('你好',price)


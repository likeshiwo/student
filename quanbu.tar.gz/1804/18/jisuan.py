class Qiji:
    __init_oy=True
    __new_yy=None
    def __init__(self,name):
        if Qiji.__init_oy==True:
            self.name=name
            Qiji.__init_oy=False

    def __new__(cls,*k):
        if cls.__new_yy==None:
            cls.__new_yy=object.__new__(cls)
        return cls.__new_yy
    def nbame(self):
        print('欢迎使用:%s'% self.name)
    def digui(self):
        while True:
            try:
                yi=int(input('请输入数字:'))
                san=input('输入计算符号:')
                er=int(input('请输入数字:'))
                if san=='/':
                    s=yi/er
                    print(yi,san,er,'=',s)
                elif san=='*':
                    s=yi*er
                    print(yi,san,er,'=',s)
                elif san=='+':
                    s=yi+er
                    print(yi,san,er,'=',s)
                elif san=='-':
                    s=yi-er
                    print(yi,san,er,'=',s)

                else:
                    print('符号输入错误!!')
                jixu=input('不使用输入q,使用请无视:')

                if jixu=='q':
                    break
            except Exception as result:
                print('有异常!!')
                print('异常信息为:',result)
                print('请按照要求输入!')


suanji=Qiji('飞利客计算机')
suanji.nbame()
suanji.digui()




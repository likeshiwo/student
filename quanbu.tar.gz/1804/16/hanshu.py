def hanshu():
    tangshi=f=open('tangshi','r')
    b=f.read()
    name=input('请输入你要打开的文件名:')
    if name=='tangshi':
        print(b)
    else:
        f=open(name,'w')
        f.write('哈哈哈')
        f=open(name,'r')
        print(f.read())
        f.close()
hanshu()

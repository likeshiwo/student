import random
x=random.randint(1,101)
while True:
    num=int(input('猜猜这个数是多少:'))
    if num>x:
        print('你猜得太大了')
    elif num<x:
        print('你猜的太小了')
    else:
        print('猜对了')
        break

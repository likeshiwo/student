class Animal:
    def __init__(self):
        self.legs=4
    def eat(self):
        print('会吃')
class gou(Animal):
    def __init__(self,name):
        self.name=name
dog=gou('阿拉加斯')
dog.eat()



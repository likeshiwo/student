'''
1.创建一个学生类
2.初始化学生类的属性：名字，性别，年龄，成绩字典
3.添加一个方法：增加/录入成绩（‘语文：60’）
4.创建3个学生
5.通过循环给每个学生，录入成绩，包括(语文，数学，英语，政治，计算机)
6.用print打印每个学生对象的 详细信息包含成绩 str
7.把打印的内容保存到文件里边
'''
class People:
    def __init__(self,name,sex,age):
        self.name=name
        self.sex=sex
        self.age=age
        self.zidian={}
    def luru(self,k,v):
        self.zidian[k]=v
    def __str__(self):
        print('姓名:%s,性别:%s,年龄:%d,成绩:'% (self.name,self.sex,self.age,self.zidian))

xiaoming=People('小明','男',18)
xiaojun=People('小军','男',19)
xiaohua=People('小花','女',20)
for i in range(1,7):
    k=input('输入科目"')
    v=input('输入成绩:')
    xiaoming.luru(k,v)
print(xiaoming)
f=open('name.txt','w')
f.wrtie(self.__str__)
f=open('name.txt','r')
print(f.read())


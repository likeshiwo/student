class MyError(Exception):
    def __init__(self,name):
        self.name=name
def yichang():
    num=input('请输入6位数密码:')
    if len(num)<6:
        raise MyError('密码不可少于6位!')
try:
    yichang()
except Exception as rb:
    print('密码输入错误,%s'% rb)

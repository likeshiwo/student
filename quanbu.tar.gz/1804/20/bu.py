l=[]
import random
a=0
while True:
    pc = random.randint(1,10)
    l.append(pc)
    print(l)
    a+=1
    if a== 9:
        break

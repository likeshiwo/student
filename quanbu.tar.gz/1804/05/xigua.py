price=input('请输入价格:')
weight=input('请输入重量:')
price=float(price)
weight=float(weight)
money=price*weight
print('该西瓜的重量是:',weight)
print('该西瓜的价格是:',price)
print('该西瓜的总价是:',money)

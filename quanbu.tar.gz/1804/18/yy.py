L=[x*2 for x in range(1,10)]
print(L)
for i in L:
    print(i)

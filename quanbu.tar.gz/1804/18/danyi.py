class People(object):
    __oob=None
    __init_bb = 1
    def __init__(self,name):
        if People.__init_bb==1:
            self.name=name
            People.__init_bb=2
    def __new__(cls,*k):
        if cls.__oob==None:
            cls.__oob=object.__new__(cls)
        return cls.__oob
people=People('李客')
heo=People('unkept')
print(people.name)
print(heo.name)
print(id(people))
print(id(heo))


import random
print('玩个游戏把？1为石头，2为布，3为剪刀')
user=int(input('猜拳游戏谁输请个菠萝，1为石头/2为布/3为剪刀:'))
pc = random.randint(1,3)
print('斯塔克出了:%d' % pc)
if pc==1:
    print('石头')
elif pc==2:
    print('布')
else:
    print('剪刀')
if user==1 and pc==3 or user==2 and pc==1 or user==3 and pc==2:
    print('让你吃个菠萝把')
elif user==1 and pc==2 or user==2 and pc==3 or user==3 and pc==1:
    print('算了吧，菠萝我吃不了。周末带我打打游戏就行')
elif user=='pc':
    print('哟，小东西不错啊')
else:
    print('再TM乱输，我锤死你')

class People:
    def __init__(self,name,height,weight):
        self.name=name
        self.height=height
        self.weight=weight
    def jump(self):
        print('%s 跳起来了......'% self.name)
    def quan(self):
        print('%s 出了直拳......'% self.name)
    def run(self):
        print('%s 跑了起来......'% self.name)
    def si(self):
        print('%s 阵亡了????!!'% self.name)
    def duo(self):
        print('%s 躲了过去......'% self.name)
    def dun(self):
        print('%s 顿了下去......'% self.name)
caotijing=People('草鹈京','180','120')
bashen=People('八神','183','130')
caotijing.jump()
bashen.dun()
caotijing.quan()
bashen.duo()
caotijing.run()
bashen.si()

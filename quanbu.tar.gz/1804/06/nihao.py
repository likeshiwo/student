import random
n=random.randint(1,100)
print('生成随机数为%d'% n)
i=0
while Ture:
    num=int(input('输入你猜的数字1-100:'))
i+=1
if (num>n):
    print('错误，数字忒大了!')
elif (num<n):
    print('错误，数字忒小了!')
else:
    print('OJBK回答正确！')
break
if i==1:
    print('nb,天选之子!')
else:
    print('你们猜的忒慢了')

list=[11]
list.append(55)
a=[12,45]
list.append(a)
list.remove(11)
print(list)
s=(100-25*3%4)
print(s)

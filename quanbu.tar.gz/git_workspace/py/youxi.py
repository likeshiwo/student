print('欢迎来到我的世界, 这里的一切都有我说的算!')
name=input('请先出入你的名字:')
print('好的',name,'温馨提示:(你可以无限制的复活) 这个世界充满了危险!')
print('你现在有三个任务：')
money=int(input('请充值:'))
if money<=1000:
    sharen=1
    while sharen<=5:
        print('第一个任务是:(说话间，村长拿出匕首杀掉了你)')
        chonglai=input('大侠,胜败乃兵家常事！请重新来过!(yes/no:)')
        if chonglai=='yes':
            sharen=sharen+1
        print('恭喜',name,'你顺利的通过第一关!')
        print('第二个任务是:你需要去收集装备')
else:
    ('呵呵，你个垃圾还玩游戏?')
    jianlaji=5
    while jianlaji<=5:
        print('你遇到一个渣渣灰，并被他打死了')
        kaishi=input('大侠，胜败乃兵家！常事请重新来过!(yes/no):')
        if kaishi=='yes':
            jianlaji=jianlaji+1
        print('哟!这么强！下一个')
        print('第三个任务是:你需要闯过毒区进入BOSS关卡')
    else:
        ('呵呵，你个丑逼玩什么游戏?')
        du=7
        while du<7:
            print('你在毒圈里面被毒死了!')
            ky=input('大侠，胜败乃兵家常事！请重新来过!(yes/no):')
            if ky=='yes':
                du=du+1
            print('very good boy 下面最后一关了!')
            print('你站在BOSS面前')
            print('嘴里口吐白沫,穿着一身破烂说:大大大大大哥别杀我!')
        else:
            print('呵呵，你个穷逼玩什么游戏!')
            boss=20
            while boss<20:
                print('BOSS没有看你一眼把你给秒了!')
                woqu=input('大侠，胜败乃兵家常事!请重新来过!(yes/no):')
                if woqu=='yes':
                    boss=boss+1
                print('你成功把BOSS给磨死了!获得以下特殊秘件!')
            else:
                print('为什么你不试试多充点钱呢?')
else:
    print('恭喜你成功收买村长，成功通过第一关!')
    print('你获得999级屠龙宝刀!神级坐骑，成功通过第二关!')
    print('你吃着水果抱着美女坐着坐骑，成功通过了第三关!')
    print('你身穿黄站战甲，手握屠龙宝刀，胯下封魔赤兔马地立在BOSS前!')
    hello=int(input('秒了他请充值1000元，去掉脑袋放到城墙上面请充值1500,正常消灭请充值:'))
    if hello >1500:
        print('你赢得了圈镇的希望!并且娶了国王的女儿，过上了幸福的生活')
    elif hello <1000 and hello <1500:
        print('你将它秒杀了，救出村长的女儿，并过上了幸福的生活')
    else:
        print('你成功的杀掉了BOSS，让世界过上和平的生活后，归隐田园....')















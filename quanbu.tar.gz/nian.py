year=int(input('请输入你要计算的年(2000~3000):'))
while year>=1000 and year<=3000:
    if year%4==0 and year%100!=0:
        print(year,':''该年为润年')
    elif year%400==0:
        print(year,':''该年为润年')
    else:
        print(year,':''该年为平年')
    year=year+1

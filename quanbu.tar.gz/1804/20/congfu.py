import random
l=[]
a=0
while len(l)<=5:
    pc=random.randint(1,5)
    l.append(pc)
    b=l[a]
    a=a+1
    if l.count(b)>1:
        l.pop()
    print(l)

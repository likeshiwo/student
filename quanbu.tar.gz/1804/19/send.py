def send():
    print('我又来了')
def ok():
    print('你是真的叼')
if __name__=='__main__':
    print('测试而已')
    send()
    ok()
#__all__=['ok']

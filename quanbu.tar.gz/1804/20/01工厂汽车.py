class Buy:
    def __init__(self,name):
        self.name=name
    def think(self,car):
        if car=='宝马':
            print('一共100W')
        elif car=='奔驰':
            print('一共50W')
class Mai(Buy):
    def do(self):
        print('制作中....')
che=Buy()
name=input('请输入你想制作的车:')
che.think(name)

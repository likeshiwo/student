#import mokuai
#mokuai.sengd()
from mokuai import *
sengd()
ok()

def zou():
    print('哈哈')

import re
re.match('1[^012]\d{10}$','手机号')

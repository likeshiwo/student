account='like'
passwd = 345225147
print('account=:',account)
print('passwd=:',passwd)

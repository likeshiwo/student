try:
    print(name)
except NameError:
    print('错误')

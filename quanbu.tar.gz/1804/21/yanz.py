def wai(sun):
    def nei():
        name=input('请输入密码:')
        if name=='11211':
            suma=input('输入要打开的文件:')
            if suma=='f1':
                sun()
            elif suma=='f2':
                sun()
            elif suma=='f3':
                sun()
            elif suma=='f4':
                sun()

        else:
            print('无权')

    return nei

@wai
def f1():
    print('有权')
@wai
def f2():
    print('可以')
@wai
def f3():
    print('OK')
@wai
def f4():
    print('啦好')
#wai()()
f1()

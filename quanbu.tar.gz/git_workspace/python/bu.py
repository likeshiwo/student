100>a>50
if a>50:
    print(123)
elif a>50 and a<70:
    print(456)
else:
    print(111)

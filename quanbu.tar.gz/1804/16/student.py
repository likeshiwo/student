class student():
    def __init__(self,name,age):
        self.name=name
        self.age=age
        shuxue=input('输入数学成绩:')
        yuwen=input('输入语文成绩:')
        yinyu=input('输入英语成绩:')
        cj={'数学':shuxue,'语文':yuwen,'英语':yinyu}
        self.height=max(cj.values())


    def __str__(self):
        str='学生名字是:%s,年龄是:%s,他的最高成绩是:%s'% (self.name,self.age,self.height)
        return str
name=input('输入你的姓名:')
age=int(input('输入你的年龄:'))
xs=student(name,age)
print(xs)


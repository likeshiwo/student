def bb():
    print('bb')
